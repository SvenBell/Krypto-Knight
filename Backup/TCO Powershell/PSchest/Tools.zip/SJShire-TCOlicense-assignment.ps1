﻿#TCOlicense-assignment.ps1
#
#Improvements: Ensure enough licenses available
#
#$Credentials = Get-Credential
#Connect-MsolService -Credential $credentials
Connect-MsolService

#Find the SKU id for TCO
get-MsolAccountSku
#Example
#AccountSkuId                                   ActiveUnits WarningUnits ConsumedUnits
#------------                                   ----------- ------------ -------------
#reseller-account:FLOW_FREE                     10000       0            8            
#reseller-account:MCOCAP                        25          0            1            Common Area Phone
#reseller-account:MCOPSTNEAU2                   91          0            26           Telstra Calling for Office 365
#sjshirewagovau:MCOPSTNEAU2
#reseller-account:SPE_E5                        87          0            84           Microsoft 365 E5
#reseller-account:SPE_E3                        87          0            84           Microsoft 365 E3
#reseller-account:RIGHTSMANAGEMENT_ADHOC        10000       0            1            
#reseller-account:O365_BUSINESS_ESSENTIALS      1           0            1            MICROSOFT 365 BUSINESS BASIC
#reseller-account:O365_BUSINESS_PREMIUM         1           0            1            MICROSOFT 365 BUSINESS STANDARD
#reseller-account:DESKLESSPACK                  20          0            17           OFFICE 365 F1
#reseller-account:STANDARDPACK                  20          0            17           OFFICE 365 E1
#reseller-account:ENTERPRISEPACK                50          0            5            OFFICE 365 E3
#reseller-account:ENTERPRISEPREMIUM_NOPSTNCONF  50          0            5            OFFICE 365 E5 WITHOUT AUDIO CONFERENCING
#reseller-account:ENTERPRISEPREMIUM             50          0            5            OFFICE 365 E5
#reseller-account:MCOEV                         50          0            6            MICROSOFT PHONE SYSTEM
#reseller-account:EXCHANGEDESKLESS              2           0            2            EXCHANGE ONLINE KIOSK
#reseller-account:PHONESYSTEM_VIRTUALUSER       10          0            4            Microsoft 365 Phone System - Virtual User
#reseller-account:EXCHANGESTANDARD              2           0            2            EXCHANGE ONLINE (PLAN 1)
#reseller-account:O365_BUSINESS_PREMIUM         55          0            52           MICROSOFT 365 BUSINESS STANDARD
#reseller-account:POWER_BI_STANDARD             1000000     0            58           Power BI (free)
#reseller-account:TEAMS_EXPLORATORY             100         0            6            Microsoft Teams Exploratory
#reseller-account:TEAMS_COMMERCIAL_TRIAL        500000      0            0            Microsoft Teams Commercial trial
#reseller-account:MCOMEETADV                    1           0            1            AUDIO CONFERENCING
#
#Ref. https://docs.microsoft.com/en-us/azure/active-directory/users-groups-roles/licensing-service-plan-reference


#Add the SKU id you want to add license for
$SKU1 = "sjshirewagovau:MCOPSTNEAU2"
#Add the new Office SKU id you want to add
$SKUAdd1 = "sjshirewagovau:ENTERPRISEPACK"
#Add the new Office SKU id you want to replace/remove
$SKURem1 = "sjshirewagovau:O365_BUSINESS_PREMIUM"
#Filename is the csv with user list heading UPN
$Filename = "C:\tools\Temp\sjshirewagovau-extras.csv"


    $users = Import-Csv $FileName
# Done already above...   Connect-MSOLService
    foreach ($user in $users)
    {
        #Extract User's UPN from CSV file line - -verbose outputs to screen
        $upn= $user.UPN
        write-host $upn -foregroundcolor Green
        #Log current users license status to pre change log file
        Get-Msoluser -UserPrincipalName $upn | select UserPrincipalName,UsageLocation,@{n="Licenses Type";e={$_.Licenses.AccountSKUid}},DisplayName | export-csv "C:\tools\temp\sjshirewagovau-license-log.csv" -Append -NoTypeInformation
        #Set users usage location to Australia
        Set-MsolUser -UserPrincipalName $upn -UsageLocation "AU" -verbose
        #Add O365 E3 and remove M365 Business Premium license
        #Set-MsolUserLicense -UserPrincipalName $upn -AddLicenses $SKUAdd1 -RemoveLicenses $SKURem1 -Verbose
        #Add Microsoft Phone System License
        Set-MsolUserLicense -UserPrincipalName $upn -AddLicenses "sjshirewagovau:MCOEV" -Verbose
        #Add Telstra Calling for Office 365 - Premium license
        Set-MsolUserLicense -UserPrincipalName $upn -AddLicenses "sjshirewagovau:MCOPSTNEAU2" -Verbose
        #Log current users license status to post change log file
        Get-Msoluser -UserPrincipalName $upn | select UserPrincipalName,UsageLocation,@{n="Licenses Type";e={$_.Licenses.AccountSKUid}},DisplayName | export-csv "C:\tools\temp\sjshirewagovau-license-log.csv" -Append -NoTypeInformation
    } 


        $users = Import-Csv $FileName
# Done already above...   Connect-MSOLService
    foreach ($user in $users)
    {
        #Extract User's UPN from CSV file line - -verbose outputs to screen
        $upn= $user.UPN
        write-host $upn -foregroundcolor Green
        #Log current users license status to pre change log file
        #Get-Msoluser -UserPrincipalName $upn | select UserPrincipalName,UsageLocation,@{n="Licenses Type";e={$_.Licenses.AccountSKUid}},DisplayName | export-csv "C:\tools\temp\sjshirewagovau-license-log.csv" -Append -NoTypeInformation
        #Set users usage location to Australia
        #Set-MsolUser -UserPrincipalName $upn -UsageLocation "AU" -verbose
        #Add O365 E3 and remove M365 Business Premium license
        #Set-MsolUserLicense -UserPrincipalName $upn -AddLicenses $SKUAdd1 -RemoveLicenses $SKURem1 -Verbose
        #Add Microsoft Phone System License
        #Set-MsolUserLicense -UserPrincipalName $upn -AddLicenses "sjshirewagovau:MCOEV" -Verbose
        #Add Telstra Calling for Office 365 - Premium license
        #Set-MsolUserLicense -UserPrincipalName $upn -AddLicenses "sjshirewagovau:MCOPSTNEAU2" -Verbose
        #Log current users license status to post change log file
        Get-Msoluser -UserPrincipalName $upn | select UserPrincipalName,UsageLocation,@{n="Licenses Type";e={$_.Licenses.AccountSKUid}},DisplayName | export-csv "C:\tools\temp\sjshirewagovau-license-check-log.csv" -Append -NoTypeInformation
    } 