﻿C:\Program Files (x86)\Microsoft Skype for Business Network Assessment Tool> .\NetworkAssessmentTool.exe /connectivitycheck /verbose

Copy C:\Users\admin\AppData\Local\Microsoft Skype for Business Network Assessment Tool\connectivity_results.txt to #desktop??

./resultsanalyzer.exe "C:\Users\admin\AppData\Local\Microsoft Skype for Business Network Assessment Tool\performance_results.tsv"

cd "C:\Program Files (x86)\Microsoft Skype for Business Network Assessment Tool"
./resultsanalyzer.exe "C:\_Install\HQ_performance_results.tsv"

./resultsanalyzer.exe "C:\_Install\Network Assessment\Airport\performance_results.tsv"

./resultsanalyzer.exe "C:\_Install\Network Assessment\library\performance_results.tsv"

./resultsanalyzer.exe "C:\_Install\Network Assessment\youth\performance_results.tsv"

./resultsanalyzer.exe "C:\_Install\Network Assessment\Depot\performance_results.tsv"

