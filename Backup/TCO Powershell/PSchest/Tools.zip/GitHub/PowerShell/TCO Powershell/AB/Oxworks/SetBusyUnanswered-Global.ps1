﻿Connect-MicrosoftTeams

Set-CsTeamsCallingPolicy -id "Global" -BusyOnBusyEnabledType "unanswered"

Disconnect-MicrosoftTeams