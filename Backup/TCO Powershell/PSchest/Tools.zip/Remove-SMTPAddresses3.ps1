$alias = Get-Mailbox -ResultSize Unlimited | Where {$_.EmailAddresses -like {'*HNC.ORG.AU'}}
$alias | Select-Object -property SamAccountName,UserPrincipalName,EmailAddresses,PrimarySmtpAddress | Export-Csv {“mailboxes_with_HNC_ORG_AU.csv”}

foreach($L in $alias)
{
$x = $L
$y = $x.EmailAddresses | where{$_.AddressString -like {'*@HNC.ORG.AU'}}
$z = $y.SmtpAddress
$T = $x.UserPrincipalName
Write-host $x.EmailAddresses
Write-host {“*****”}
if($z){
$x.EmailAddresses -= $z
$x | Set-mailbox
Write-Host {“$z is removed”}
Write-Host {“Check”}
Write-host $x.EmailAddresses
}else{
Write-Host {“$T does not have a HNC.ORG.AU SMTP Address.”}
}
Write-host {“####################################################”}
#Return
}