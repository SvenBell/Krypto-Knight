﻿#----------------------------------------------
#region Import Assemblies
#----------------------------------------------
[void][Reflection.Assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')
[void][Reflection.Assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')
[void][Reflection.Assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')
[void][Reflection.Assembly]::Load('System.DirectoryServices, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')
#endregion Import Assemblies

function Main {
<#
    .SYNOPSIS
        The Main function starts the project application.
    
    .PARAMETER Commandline
        $Commandline contains the complete argument string passed to the script packager executable.
    
    .NOTES
        Use this function to initialize your script and to call GUI forms.
		
    .NOTES
        To get the console output in the Packager (Forms Engine) use: 
		$ConsoleOutput (Type: System.Collections.ArrayList)
#>
	Param ([String]$Commandline)
		
	#--------------------------------------------------------------------------
	#TODO: Add initialization script here (Load modules and check requirements)
	
	
	#--------------------------------------------------------------------------
	
	if((Show-MainForm_psf) -eq 'OK')
	{
		
	}
	
	$script:ExitCode = 0 #Set the exit code for the Packager
}

#endregion Source: Startup.pss

#region Source: MainForm.psf
function Show-MainForm_psf
{
	#----------------------------------------------
	#region Import the Assemblies
	#----------------------------------------------
	[void][reflection.assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')
	[void][reflection.assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')
	[void][reflection.assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')
	[void][reflection.assembly]::Load('System.DirectoryServices, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')
	[void][reflection.assembly]::Load('System.Design, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')
	#endregion Import Assemblies

	#----------------------------------------------
	#region Generated Form Objects
	#----------------------------------------------
	[System.Windows.Forms.Application]::EnableVisualStyles()
	$MainForm = New-Object 'System.Windows.Forms.Form'
	$checkboxConnectSkypeForBusin = New-Object 'System.Windows.Forms.CheckBox'
	$checkboxConnectSharePointOnl = New-Object 'System.Windows.Forms.CheckBox'
	$checkboxConnectExchangeOnlin = New-Object 'System.Windows.Forms.CheckBox'
	$combobox1 = New-Object 'System.Windows.Forms.ComboBox'
	$buttonConnect = New-Object 'System.Windows.Forms.Button'
	$labelChooseProfile = New-Object 'System.Windows.Forms.Label'
	$menustrip1 = New-Object 'System.Windows.Forms.MenuStrip'
	$fileToolStripMenuItem = New-Object 'System.Windows.Forms.ToolStripMenuItem'
	$toolsToolStripMenuItem = New-Object 'System.Windows.Forms.ToolStripMenuItem'
	$helpToolStripMenuItem = New-Object 'System.Windows.Forms.ToolStripMenuItem'
	$aboutToolStripMenuItem = New-Object 'System.Windows.Forms.ToolStripMenuItem'
	$exitToolStripMenuItem = New-Object 'System.Windows.Forms.ToolStripMenuItem'
	$profileManagerToolStripMenuItem = New-Object 'System.Windows.Forms.ToolStripMenuItem'
	$InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState'
	#endregion Generated Form Objects

	#----------------------------------------------
	# User Generated Script
	#----------------------------------------------
	$MainForm_Load={
	#TODO: Initialize Form Controls here
		
		$WorkingDirectory = (Get-Location).Path
		$Path = $WorkingDirectory + "./O365-Connector-Settings.xml"
		
		#If configuration file does not exists, create new XML file and insert default profile;
		if (![System.IO.File]::Exists($Path))
		{
			$XmlWriteHandler = New-Object System.XMl.XmlTextWriter($Path, $Null)
			$XmlWriteHandler.WriteProcessingInstruction("xml", "version='1.0' encoding='UTF-8'")
			$XmlWriteHandler.WriteStartElement('ConnectionProfiles')
			
			$XmlWriteHandler.WriteStartElement('Profile')
			$XmlWriteHandler.WriteStartElement('ProfileName')
			$XmlWriteHandler.WriteRaw("Default-Contoso")
			$XmlWriteHandler.WriteEndElement()
			
			$XmlWriteHandler.WriteStartElement('UserName')
			$XmlWriteHandler.WriteRaw("admin@contoso.onmicrosoft.com")
			$XmlWriteHandler.WriteEndElement()
			
			$XmlWriteHandler.WriteStartElement('Password')
			$XmlWriteHandler.WriteRaw("DefaultPassword")
			$XmlWriteHandler.WriteEndElement()
			
			$XmlWriteHandler.WriteEndElement()
			$XmlWriteHandler.WriteEndElement()
			
			#Finalizing XML document;
			$XmlWriteHandler.Flush()
			$XmlWriteHandler.Close()
		}
		#Read profile names into combobox selector;
		[xml]$ProfileList = Get-Content $Path
		
		$Profiles = $ProfileList.ConnectionProfiles.Profile
		foreach ($Profile in $Profiles)
		{
			$combobox1.Items.Add($Profile.ProfileName)
		}
		
		if (-not (Get-Module -ListAvailable -Name "Microsoft.Online.SharePoint.PowerShell"))
		{
			$checkboxConnectSharePointOnl.Enabled = $false
		}
		
		if (-not (Get-Module -ListAvailable -Name "LyncOnlineConnector"))
		{
			$checkboxConnectSkypeForBusin.Enabled = $false
			$checkboxConnectSkypeForBusin.Text = "LyncOnlineConnector PS Module not found!"		
		}
		
	}
	
	$profileManagerToolStripMenuItem_Click={
		
		Show-ProfileManager_psf
	
	}
	
	$buttonConnect_Click={
		
		#Reading XML file conatining profiles;
		$WorkingDirectory = (Get-Location).Path
		$Path = $WorkingDirectory + "./O365-Connector-Settings.xml"
		[xml]$ProfileList = Get-Content $Path
		
		$TargetProfile = $Profilelist.ConnectionProfiles.Profile | where { $_.ProfileName -eq $combobox1.SelectedItem }
		
		#Initial connection string created based on profile selection;
		$ConnectionString = $TargetProfile.UserName + "|" + $TargetProfile.Password + "|AD1" + "|EXO0" + "|SPO0"
		
		#If Connect to EXO checkbox is checked, connection string is amended;
		if ($checkboxConnectExchangeOnlin.Checked -eq $true)
		{
			$ConnectionString = $ConnectionString -replace 'EXO0','EXO1'
		}
		
		if ($checkboxConnectSharePointOnl.Checked -eq $true)
		{
			$ConnectionString = $ConnectionString -replace 'SPO0', 'SPO1'
		}
		
		#Building up connection script block;
		$ScriptBlock = {
			function ConnectionScript($CString)
			{
				#Reading connection string and connecting to MSOL using credentials from it;
				$TUserName = $CString.Split('|')[0].Trim()
				$TPasswordTemp = $CString.Split('|')[1].Trim()
				$TPassword = ConvertTo-SecureString $TPasswordTemp
				$Credentials1 = New-object -typename System.Management.Automation.PSCredential -argumentlist $TUserName, $TPassword
				Connect-MsolService -Credential $Credentials1 -Verbose
				
				#Displaying tenant information in PowerShell window header;
				$OrgName = Get-MsolCompanyInformation | select -exp DisplayName
				$InitialDomain = Get-MsolCompanyInformation | select -exp InitialDomain
				$WindowHeaderString = 'Connected to ' + $OrgName + ' (' + $InitialDomain + ')' + ' services: AzureAD'
				
				#If EXO is set to EXO1 in connection string, connect to Exchange Online using same credentials;
				if ($CString.Split('|')[3].Trim() -eq 'EXO1')
				{
					$URI = 'https://ps.outlook.com/powershell'
					$PSSession1 = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri $URI -Credential $Credentials1 -Authentication basic -AllowRedirection
					Import-PSSession $PSSession1 -AllowClobber
					$WindowHeaderString = $WindowHeaderString + ', EXO'
					
				}
				
				if ($CString.Split('|')[4].Trim() -eq 'SPO1')
				{
					$DefaultDomainName = $InitialDomain.Split('.')[0].Trim()
					Import-Module Microsoft.Online.SharePoint.PowerShell -DisableNameChecking
					$URL = 'https://' + $DefaultDomainName + '-admin.sharepoint.com'
					Connect-SPOService -Url $URL -Credential $Credentials1
					$WindowHeaderString = $WindowHeaderString + ', SPO'
				}
				
				$host.ui.RawUI.WindowTitle = $WindowHeaderString
			}
		}
		
		#Execution of connection script in new PowerShell window;
		Start-Process powershell -ArgumentList "-noexit", "-Command & {$ScriptBlock ConnectionScript('$ConnectionString')}"
	}
	
	$aboutToolStripMenuItem_Click={
		
		Show-HelpForm_psf
	}
	$exitToolStripMenuItem_Click={
	
		$MainForm.Close()
	}
	
	$checkboxConnectSharePointOnl_CheckedChanged={
		#TODO: Place custom script here
		
	}
	
	$combobox1_SelectedIndexChanged={
		#TODO: Place custom script here
		$buttonConnect.Enabled = $true
	}
	
	$checkboxConnectSkypeForBusin_CheckedChanged={
		#TODO: Place custom script here
		
	}
		# --End User Generated Script--
	#----------------------------------------------
	#region Generated Events
	#----------------------------------------------
	
	$Form_StateCorrection_Load=
	{
		#Correct the initial state of the form to prevent the .Net maximized form issue
		$MainForm.WindowState = $InitialFormWindowState
	}
	
	$Form_StoreValues_Closing=
	{
		#Store the control values
		$script:MainForm_checkboxConnectSkypeForBusin = $checkboxConnectSkypeForBusin.Checked
		$script:MainForm_checkboxConnectSharePointOnl = $checkboxConnectSharePointOnl.Checked
		$script:MainForm_checkboxConnectExchangeOnlin = $checkboxConnectExchangeOnlin.Checked
		$script:MainForm_combobox1 = $combobox1.Text
		$script:MainForm_combobox1_SelectedItem = $combobox1.SelectedItem
	}

	
	$Form_Cleanup_FormClosed=
	{
		#Remove all event handlers from the controls
		try
		{
			$checkboxConnectSkypeForBusin.remove_CheckedChanged($checkboxConnectSkypeForBusin_CheckedChanged)
			$checkboxConnectSharePointOnl.remove_CheckedChanged($checkboxConnectSharePointOnl_CheckedChanged)
			$combobox1.remove_SelectedIndexChanged($combobox1_SelectedIndexChanged)
			$buttonConnect.remove_Click($buttonConnect_Click)
			$MainForm.remove_Load($MainForm_Load)
			$aboutToolStripMenuItem.remove_Click($aboutToolStripMenuItem_Click)
			$exitToolStripMenuItem.remove_Click($exitToolStripMenuItem_Click)
			$profileManagerToolStripMenuItem.remove_Click($profileManagerToolStripMenuItem_Click)
			$MainForm.remove_Load($Form_StateCorrection_Load)
			$MainForm.remove_Closing($Form_StoreValues_Closing)
			$MainForm.remove_FormClosed($Form_Cleanup_FormClosed)
		}
		catch { Out-Null <# Prevent PSScriptAnalyzer warning #> }
	}
	#endregion Generated Events

	#----------------------------------------------
	#region Generated Form Code
	#----------------------------------------------
	$MainForm.SuspendLayout()
	$menustrip1.SuspendLayout()
	#
	# MainForm
	#
	$MainForm.Controls.Add($checkboxConnectSkypeForBusin)
	$MainForm.Controls.Add($checkboxConnectSharePointOnl)
	$MainForm.Controls.Add($checkboxConnectExchangeOnlin)
	$MainForm.Controls.Add($combobox1)
	$MainForm.Controls.Add($buttonConnect)
	$MainForm.Controls.Add($labelChooseProfile)
	$MainForm.Controls.Add($menustrip1)
	$MainForm.AutoScaleDimensions = '6, 13'
	$MainForm.AutoScaleMode = 'Font'
	$MainForm.ClientSize = '371, 252'
	$MainForm.FormBorderStyle = 'FixedSingle'
	$MainForm.MainMenuStrip = $menustrip1
	$MainForm.MaximizeBox = $False
	$MainForm.Name = 'MainForm'
	$MainForm.SizeGripStyle = 'Hide'
	$MainForm.StartPosition = 'CenterScreen'
	$MainForm.Text = 'Office 365 Connector'
	$MainForm.add_Load($MainForm_Load)
	#
	# checkboxConnectSkypeForBusin
	#
	$checkboxConnectSkypeForBusin.Location = '23, 158'
	$checkboxConnectSkypeForBusin.Name = 'checkboxConnectSkypeForBusin'
	$checkboxConnectSkypeForBusin.Size = '198, 39'
	$checkboxConnectSkypeForBusin.TabIndex = 7
	$checkboxConnectSkypeForBusin.Text = 'Connect Skype for Business Online'
	$checkboxConnectSkypeForBusin.UseVisualStyleBackColor = $True
	$checkboxConnectSkypeForBusin.Visible = $False
	$checkboxConnectSkypeForBusin.add_CheckedChanged($checkboxConnectSkypeForBusin_CheckedChanged)
	#
	# checkboxConnectSharePointOnl
	#
	$checkboxConnectSharePointOnl.Location = '23, 137'
	$checkboxConnectSharePointOnl.Name = 'checkboxConnectSharePointOnl'
	$checkboxConnectSharePointOnl.Size = '182, 24'
	$checkboxConnectSharePointOnl.TabIndex = 6
	$checkboxConnectSharePointOnl.Text = 'Connect SharePoint Online'
	$checkboxConnectSharePointOnl.UseVisualStyleBackColor = $True
	$checkboxConnectSharePointOnl.add_CheckedChanged($checkboxConnectSharePointOnl_CheckedChanged)
	#
	# checkboxConnectExchangeOnlin
	#
	$checkboxConnectExchangeOnlin.Checked = $True
	$checkboxConnectExchangeOnlin.CheckState = 'Checked'
	$checkboxConnectExchangeOnlin.Location = '23, 107'
	$checkboxConnectExchangeOnlin.Name = 'checkboxConnectExchangeOnlin'
	$checkboxConnectExchangeOnlin.Size = '198, 24'
	$checkboxConnectExchangeOnlin.TabIndex = 5
	$checkboxConnectExchangeOnlin.Text = 'Connect Exchange Online'
	$checkboxConnectExchangeOnlin.UseVisualStyleBackColor = $True
	#
	# combobox1
	#
	$combobox1.DropDownStyle = 'DropDownList'
	$combobox1.FormattingEnabled = $True
	$combobox1.Location = '100, 49'
	$combobox1.Name = 'combobox1'
	$combobox1.Size = '150, 21'
	$combobox1.TabIndex = 4
	$combobox1.add_SelectedIndexChanged($combobox1_SelectedIndexChanged)
	#
	# buttonConnect
	#
	$buttonConnect.Enabled = $False
	$buttonConnect.Location = '263, 202'
	$buttonConnect.Name = 'buttonConnect'
	$buttonConnect.Size = '75, 23'
	$buttonConnect.TabIndex = 3
	$buttonConnect.Text = 'Connect'
	$buttonConnect.UseVisualStyleBackColor = $True
	$buttonConnect.add_Click($buttonConnect_Click)
	#
	# labelChooseProfile
	#
	$labelChooseProfile.AutoSize = $True
	$labelChooseProfile.Location = '12, 52'
	$labelChooseProfile.Name = 'labelChooseProfile'
	$labelChooseProfile.Size = '77, 13'
	$labelChooseProfile.TabIndex = 2
	$labelChooseProfile.Text = 'Choose profile:'
	#
	# menustrip1
	#
	[void]$menustrip1.Items.Add($fileToolStripMenuItem)
	[void]$menustrip1.Items.Add($toolsToolStripMenuItem)
	[void]$menustrip1.Items.Add($helpToolStripMenuItem)
	$menustrip1.Location = '0, 0'
	$menustrip1.Name = 'menustrip1'
	$menustrip1.Size = '371, 24'
	$menustrip1.TabIndex = 1
	$menustrip1.Text = 'menustrip1'
	#
	# fileToolStripMenuItem
	#
	[void]$fileToolStripMenuItem.DropDownItems.Add($exitToolStripMenuItem)
	$fileToolStripMenuItem.Name = 'fileToolStripMenuItem'
	$fileToolStripMenuItem.Size = '37, 20'
	$fileToolStripMenuItem.Text = 'File'
	#
	# toolsToolStripMenuItem
	#
	[void]$toolsToolStripMenuItem.DropDownItems.Add($profileManagerToolStripMenuItem)
	$toolsToolStripMenuItem.Name = 'toolsToolStripMenuItem'
	$toolsToolStripMenuItem.Size = '47, 20'
	$toolsToolStripMenuItem.Text = 'Tools'
	#
	# helpToolStripMenuItem
	#
	[void]$helpToolStripMenuItem.DropDownItems.Add($aboutToolStripMenuItem)
	$helpToolStripMenuItem.Name = 'helpToolStripMenuItem'
	$helpToolStripMenuItem.Size = '44, 20'
	$helpToolStripMenuItem.Text = 'Help'
	#
	# aboutToolStripMenuItem
	#
	$aboutToolStripMenuItem.Name = 'aboutToolStripMenuItem'
	$aboutToolStripMenuItem.Size = '152, 22'
	$aboutToolStripMenuItem.Text = 'About'
	$aboutToolStripMenuItem.add_Click($aboutToolStripMenuItem_Click)
	#
	# exitToolStripMenuItem
	#
	$exitToolStripMenuItem.Name = 'exitToolStripMenuItem'
	$exitToolStripMenuItem.Size = '152, 22'
	$exitToolStripMenuItem.Text = 'Exit'
	$exitToolStripMenuItem.add_Click($exitToolStripMenuItem_Click)
	#
	# profileManagerToolStripMenuItem
	#
	$profileManagerToolStripMenuItem.Name = 'profileManagerToolStripMenuItem'
	$profileManagerToolStripMenuItem.Size = '158, 22'
	$profileManagerToolStripMenuItem.Text = 'Profile Manager'
	$profileManagerToolStripMenuItem.add_Click($profileManagerToolStripMenuItem_Click)
	$menustrip1.ResumeLayout()
	$MainForm.ResumeLayout()
	#endregion Generated Form Code

	#----------------------------------------------

	#Save the initial state of the form
	$InitialFormWindowState = $MainForm.WindowState
	#Init the OnLoad event to correct the initial state of the form
	$MainForm.add_Load($Form_StateCorrection_Load)
	#Clean up the control events
	$MainForm.add_FormClosed($Form_Cleanup_FormClosed)
	#Store the control values when form is closing
	$MainForm.add_Closing($Form_StoreValues_Closing)
	#Show the Form
	return $MainForm.ShowDialog()

}
#endregion Source: MainForm.psf

#region Source: Globals.ps1
	#--------------------------------------------
	# Declare Global Variables and Functions here
	#--------------------------------------------
	
	
	#Sample function that provides the location of the script
	function Get-ScriptDirectory
	{
	<#
		.SYNOPSIS
			Get-ScriptDirectory returns the proper location of the script.
	
		.OUTPUTS
			System.String
		
		.NOTES
			Returns the correct path within a packaged executable.
	#>
		[OutputType([string])]
		param ()
		if ($null -ne $hostinvocation)
		{
			Split-Path $hostinvocation.MyCommand.path
		}
		else
		{
			Split-Path $script:MyInvocation.MyCommand.Path
		}
	}
	
	#Sample variable that provides the location of the script
	[string]$ScriptDirectory = Get-ScriptDirectory
	[bool]$NewProfile = $False
	
	
#endregion Source: Globals.ps1

#region Source: ProfileManager.psf
function Show-ProfileManager_psf
{

	#----------------------------------------------
	#region Import the Assemblies
	#----------------------------------------------
	[void][reflection.assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')
	[void][reflection.assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')
	[void][reflection.assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')
	#endregion Import Assemblies

	#----------------------------------------------
	#region Generated Form Objects
	#----------------------------------------------
	[System.Windows.Forms.Application]::EnableVisualStyles()
	$formProfileManager = New-Object 'System.Windows.Forms.Form'
	$buttonDelete = New-Object 'System.Windows.Forms.Button'
	$buttonAddProfile = New-Object 'System.Windows.Forms.Button'
	$listview1 = New-Object 'System.Windows.Forms.ListView'
	$buttonClose = New-Object 'System.Windows.Forms.Button'
	$InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState'
	#endregion Generated Form Objects

	#----------------------------------------------
	# User Generated Script
	#----------------------------------------------
	$formProfileManager_Load={
		#TODO: Initialize Form Controls here
		
		#Read profiles from XML configuration file into ListView window;
		$WorkingDirectory = (Get-Location).Path
		$Path = $WorkingDirectory + "./O365-Connector-Settings.xml"
		[xml]$ProfileList = Get-Content $Path
		
		$Profiles = $ProfileList.ConnectionProfiles.Profile
		
		foreach ($Profile in $Profiles)
		{
			$listview1.Items.Add($Profile.ProfileName)		
		}
	
	}
	
	#Setting NewProfile trigger to False if user clicks one of the profiles in ListView
	$listview1_MouseDoubleClick=[System.Windows.Forms.MouseEventHandler]{
	
	#	$NewProfile = $False
	#	Show-EditProfile_psf 
	}
	
	#Setting NewProfile trigger to True is Add Profile button is clicked
	$buttonAddProfile_Click={
	
		$NewProfile = $True
		Show-EditProfile_psf
	}
	$buttonDelete_Click={
		#TODO: Place custom script here
		If ($listview1.CheckedItems.Count -gt 0)
		{
			if ([System.Windows.Forms.MessageBox]::Show("Do you really want to delete selected profiles?", "Confirmation", [System.Windows.Forms.MessageBoxButtons]::OKCancel) -eq "OK")
			{
				#Reading XML config file;
				$WorkingDirectory = (Get-Location).Path
				$Path = $WorkingDirectory + "./O365-Connector-Settings.xml"
				[xml]$ProfileList = Get-Content $Path
				
				foreach ($ProfileRecord in $listview1.CheckedItems)
				{
					$Profilelist.ConnectionProfiles.Profile | where { $_.ProfileName -eq $ProfileRecord.Text } | ForEach-Object {
						# Remove each node from its parent
						[void]$_.ParentNode.RemoveChild($_)
					}
				}
				
				$ProfileList.Save($Path)
				
				$Profiles = $ProfileList.ConnectionProfiles.Profile
				
				#Reloading ListView on ProfileManager form and Combobox on MainForm to add newly created profile:
				#Reloading ListView;
				$listview1.Clear()
				foreach ($Profile in $Profiles)
				{
					$listview1.Items.Add($Profile.ProfileName)
				}
				
				#Reloading Combobox;
				$combobox1.Items.Clear()
				foreach ($Profile in $Profiles)
				{
					$combobox1.Items.Add($Profile.ProfileName)
				}
			}
		}
	}
		# --End User Generated Script--
	#----------------------------------------------
	#region Generated Events
	#----------------------------------------------
	
	$Form_StateCorrection_Load=
	{
		#Correct the initial state of the form to prevent the .Net maximized form issue
		$formProfileManager.WindowState = $InitialFormWindowState
	}
	
	$Form_StoreValues_Closing=
	{
		#Store the control values
		$script:ProfileManager_listview1 = $listview1.SelectedItems
		$script:ProfileManager_listview1_Checked = $listview1.CheckedItems
	}

	
	$Form_Cleanup_FormClosed=
	{
		#Remove all event handlers from the controls
		try
		{
			$buttonDelete.remove_Click($buttonDelete_Click)
			$buttonAddProfile.remove_Click($buttonAddProfile_Click)
			$listview1.remove_MouseDoubleClick($listview1_MouseDoubleClick)
			$formProfileManager.remove_Load($formProfileManager_Load)
			$formProfileManager.remove_Load($Form_StateCorrection_Load)
			$formProfileManager.remove_Closing($Form_StoreValues_Closing)
			$formProfileManager.remove_FormClosed($Form_Cleanup_FormClosed)
		}
		catch { Out-Null <# Prevent PSScriptAnalyzer warning #> }
	}
	#endregion Generated Events

	#----------------------------------------------
	#region Generated Form Code
	#----------------------------------------------
	$formProfileManager.SuspendLayout()
	#
	# formProfileManager
	#
	$formProfileManager.Controls.Add($buttonDelete)
	$formProfileManager.Controls.Add($buttonAddProfile)
	$formProfileManager.Controls.Add($listview1)
	$formProfileManager.Controls.Add($buttonClose)
	$formProfileManager.AutoScaleDimensions = '6, 13'
	$formProfileManager.AutoScaleMode = 'Font'
	$formProfileManager.ClientSize = '279, 213'
	$formProfileManager.Name = 'formProfileManager'
	$formProfileManager.StartPosition = 'CenterParent'
	$formProfileManager.Text = 'Profile Manager'
	$formProfileManager.add_Load($formProfileManager_Load)
	#
	# buttonDelete
	#
	$buttonDelete.Location = '189, 74'
	$buttonDelete.Name = 'buttonDelete'
	$buttonDelete.Size = '75, 23'
	$buttonDelete.TabIndex = 4
	$buttonDelete.Text = 'Delete'
	$buttonDelete.UseVisualStyleBackColor = $True
	$buttonDelete.add_Click($buttonDelete_Click)
	#
	# buttonAddProfile
	#
	$buttonAddProfile.Location = '189, 29'
	$buttonAddProfile.Name = 'buttonAddProfile'
	$buttonAddProfile.Size = '75, 23'
	$buttonAddProfile.TabIndex = 3
	$buttonAddProfile.Text = 'Add Profile'
	$buttonAddProfile.UseVisualStyleBackColor = $True
	$buttonAddProfile.add_Click($buttonAddProfile_Click)
	#
	# listview1
	#
	$listview1.CheckBoxes = $True
	$listview1.Location = '23, 29'
	$listview1.Name = 'listview1'
	$listview1.Size = '160, 121'
	$listview1.TabIndex = 2
	$listview1.UseCompatibleStateImageBehavior = $False
	$listview1.View = 'List'
	$listview1.add_MouseDoubleClick($listview1_MouseDoubleClick)
	#
	# buttonClose
	#
	$buttonClose.Anchor = 'Bottom, Right'
	$buttonClose.CausesValidation = $False
	$buttonClose.DialogResult = 'Cancel'
	$buttonClose.Location = '192, 178'
	$buttonClose.Name = 'buttonClose'
	$buttonClose.Size = '75, 23'
	$buttonClose.TabIndex = 0
	$buttonClose.Text = '&Close'
	$buttonClose.UseVisualStyleBackColor = $True
	$formProfileManager.ResumeLayout()
	#endregion Generated Form Code

	#----------------------------------------------

	#Save the initial state of the form
	$InitialFormWindowState = $formProfileManager.WindowState
	#Init the OnLoad event to correct the initial state of the form
	$formProfileManager.add_Load($Form_StateCorrection_Load)
	#Clean up the control events
	$formProfileManager.add_FormClosed($Form_Cleanup_FormClosed)
	#Store the control values when form is closing
	$formProfileManager.add_Closing($Form_StoreValues_Closing)
	#Show the Form
	return $formProfileManager.ShowDialog()

}
#endregion Source: ProfileManager.psf

#region Source: EditProfile.psf
function Show-EditProfile_psf
{

	#----------------------------------------------
	#region Import the Assemblies
	#----------------------------------------------
	[void][reflection.assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')
	[void][reflection.assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')
	[void][reflection.assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')
	#endregion Import Assemblies

	#----------------------------------------------
	#region Generated Form Objects
	#----------------------------------------------
	[System.Windows.Forms.Application]::EnableVisualStyles()
	$formEditProfile = New-Object 'System.Windows.Forms.Form'
	$textbox3 = New-Object 'System.Windows.Forms.TextBox'
	$labelProfileName = New-Object 'System.Windows.Forms.Label'
	$buttonCancel = New-Object 'System.Windows.Forms.Button'
	$buttonSave = New-Object 'System.Windows.Forms.Button'
	$textbox2 = New-Object 'System.Windows.Forms.TextBox'
	$textbox1 = New-Object 'System.Windows.Forms.TextBox'
	$labelPassword = New-Object 'System.Windows.Forms.Label'
	$labelUserName = New-Object 'System.Windows.Forms.Label'
	$InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState'
	#endregion Generated Form Objects

	#----------------------------------------------
	# User Generated Script
	#----------------------------------------------
	
	$formEditProfile_Load={
		#TODO: Initialize Form Controls here
		$textbox3.Text = $listview1.FocusedItem.Text
		
		
	}
	
	$buttonSave_Click={
		
		#Creation of new profile and saving it to XML file if NewProfile flag is True
		if ($NewProfile -eq $true)
		{
			$buttonSave.Enabled = $true
			$WorkingDirectory = (Get-Location).Path
			$Path = $WorkingDirectory + "./O365-Connector-Settings.xml"
			$XmlDoc = [System.Xml.XmlDocument](Get-Content $Path);
			
			$Profiles = $XmlDoc.ConnectionProfiles
			
			$EncryptedPassword = ConvertTo-SecureString $textbox2.Text -AsPlainText -Force
			$EncryptedPassword1 = $EncryptedPassword | ConvertFrom-SecureString
			
			$NewXmlProfile = $xmlDoc.ConnectionProfiles.AppendChild($XmlDoc.CreateElement("Profile"));
			
			$NewXmlProfileName = $NewXmlProfile.AppendChild($XmlDoc.CreateElement("ProfileName"));
			$NewXmlProfileName.AppendChild($XmlDoc.CreateTextNode($textbox3.Text));
			
			$NewXmlProfileUser = $NewXmlProfile.AppendChild($XmlDoc.CreateElement("UserName"));
			$NewXmlProfileUser.AppendChild($XmlDoc.CreateTextNode($textbox1.Text));
			
			$NewXmlProfilePass = $NewXmlProfile.AppendChild($XmlDoc.CreateElement("Password"));
			$NewXmlProfilePass.AppendChild($XmlDoc.CreateTextNode($EncryptedPassword1));
	
			$XmlDoc.Save($Path);
			
		}
		
		#Edit existing profile and saving it to XML file if NewProfile flag is False
		if ($NewProfile -eq $false)
		{
			$label1.Text = "false"
			$buttonSave.Enabled = $false
		}
		
		$formEditProfile.Close()
		
		#Reloading ListView on ProfileManager form and Combobox on MainForm to add newly created profile:
		#Reading XML config file;
		$WorkingDirectory = (Get-Location).Path
		$Path = $WorkingDirectory + "./O365-Connector-Settings.xml"
		[xml]$ProfileList = Get-Content $Path
		
		$Profiles = $ProfileList.ConnectionProfiles.Profile
		
		#Reloading ListView;
		$listview1.Clear()
		foreach ($Profile in $Profiles)
		{
			$listview1.Items.Add($Profile.ProfileName)
		}
		
		#Reloading Combobox;
		$combobox1.Items.Clear()
		foreach ($Profile in $Profiles)
		{
			$combobox1.Items.Add($Profile.ProfileName)
		}
	}
	
	$buttonCancel_Click={
		
		$formEditProfile.Close()
	}
		# --End User Generated Script--
	#----------------------------------------------
	#region Generated Events
	#----------------------------------------------
	
	$Form_StateCorrection_Load=
	{
		#Correct the initial state of the form to prevent the .Net maximized form issue
		$formEditProfile.WindowState = $InitialFormWindowState
	}
	
	$Form_StoreValues_Closing=
	{
		#Store the control values
		$script:EditProfile_textbox3 = $textbox3.Text
		$script:EditProfile_textbox2 = $textbox2.Text
		$script:EditProfile_textbox1 = $textbox1.Text
	}

	
	$Form_Cleanup_FormClosed=
	{
		#Remove all event handlers from the controls
		try
		{
			$buttonCancel.remove_Click($buttonCancel_Click)
			$buttonSave.remove_Click($buttonSave_Click)
			$formEditProfile.remove_Load($formEditProfile_Load)
			$formEditProfile.remove_Load($Form_StateCorrection_Load)
			$formEditProfile.remove_Closing($Form_StoreValues_Closing)
			$formEditProfile.remove_FormClosed($Form_Cleanup_FormClosed)
		}
		catch { Out-Null <# Prevent PSScriptAnalyzer warning #> }
	}
	#endregion Generated Events

	#----------------------------------------------
	#region Generated Form Code
	#----------------------------------------------
	$formEditProfile.SuspendLayout()
	#
	# formEditProfile
	#
	$formEditProfile.Controls.Add($textbox3)
	$formEditProfile.Controls.Add($labelProfileName)
	$formEditProfile.Controls.Add($buttonCancel)
	$formEditProfile.Controls.Add($buttonSave)
	$formEditProfile.Controls.Add($textbox2)
	$formEditProfile.Controls.Add($textbox1)
	$formEditProfile.Controls.Add($labelPassword)
	$formEditProfile.Controls.Add($labelUserName)
	$formEditProfile.AutoScaleDimensions = '6, 13'
	$formEditProfile.AutoScaleMode = 'Font'
	$formEditProfile.ClientSize = '398, 234'
	$formEditProfile.Name = 'formEditProfile'
	$formEditProfile.Text = 'Edit Profile'
	$formEditProfile.add_Load($formEditProfile_Load)
	#
	# textbox3
	#
	$textbox3.Location = '101, 43'
	$textbox3.MaxLength = 50
	$textbox3.Name = 'textbox3'
	$textbox3.Size = '142, 20'
	$textbox3.TabIndex = 7
	#
	# labelProfileName
	#
	$labelProfileName.AutoSize = $True
	$labelProfileName.Location = '18, 51'
	$labelProfileName.Name = 'labelProfileName'
	$labelProfileName.Size = '70, 13'
	$labelProfileName.TabIndex = 6
	$labelProfileName.Text = 'Profile Name:'
	#
	# buttonCancel
	#
	$buttonCancel.Location = '286, 187'
	$buttonCancel.Name = 'buttonCancel'
	$buttonCancel.Size = '75, 23'
	$buttonCancel.TabIndex = 5
	$buttonCancel.Text = 'Cancel'
	$buttonCancel.UseVisualStyleBackColor = $True
	$buttonCancel.add_Click($buttonCancel_Click)
	#
	# buttonSave
	#
	$buttonSave.Location = '198, 187'
	$buttonSave.Name = 'buttonSave'
	$buttonSave.Size = '75, 23'
	$buttonSave.TabIndex = 4
	$buttonSave.Text = 'Save'
	$buttonSave.UseVisualStyleBackColor = $True
	$buttonSave.add_Click($buttonSave_Click)
	#
	# textbox2
	#
	$textbox2.Location = '101, 133'
	$textbox2.MaxLength = 250
	$textbox2.Name = 'textbox2'
	$textbox2.PasswordChar = '*'
	$textbox2.Size = '260, 20'
	$textbox2.TabIndex = 3
	#
	# textbox1
	#
	$textbox1.Location = '101, 88'
	$textbox1.MaxLength = 250
	$textbox1.Name = 'textbox1'
	$textbox1.Size = '260, 20'
	$textbox1.TabIndex = 2
	#
	# labelPassword
	#
	$labelPassword.AutoSize = $True
	$labelPassword.Location = '32, 140'
	$labelPassword.Name = 'labelPassword'
	$labelPassword.Size = '56, 13'
	$labelPassword.TabIndex = 1
	$labelPassword.Text = 'Password:'
	#
	# labelUserName
	#
	$labelUserName.AutoSize = $True
	$labelUserName.Location = '25, 95'
	$labelUserName.Name = 'labelUserName'
	$labelUserName.Size = '63, 13'
	$labelUserName.TabIndex = 0
	$labelUserName.Text = 'User Name:'
	$formEditProfile.ResumeLayout()
	#endregion Generated Form Code

	#----------------------------------------------

	#Save the initial state of the form
	$InitialFormWindowState = $formEditProfile.WindowState
	#Init the OnLoad event to correct the initial state of the form
	$formEditProfile.add_Load($Form_StateCorrection_Load)
	#Clean up the control events
	$formEditProfile.add_FormClosed($Form_Cleanup_FormClosed)
	#Store the control values when form is closing
	$formEditProfile.add_Closing($Form_StoreValues_Closing)
	#Show the Form
	return $formEditProfile.ShowDialog()

}
#endregion Source: EditProfile.psf

#region Source: HelpForm.psf
function Show-HelpForm_psf
{

	#----------------------------------------------
	#region Import the Assemblies
	#----------------------------------------------
	[void][reflection.assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')
	[void][reflection.assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')
	[void][reflection.assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')
	#endregion Import Assemblies

	#----------------------------------------------
	#region Generated Form Objects
	#----------------------------------------------
	[System.Windows.Forms.Application]::EnableVisualStyles()
	$formAbout = New-Object 'System.Windows.Forms.Form'
	$labelVersion12Release1707 = New-Object 'System.Windows.Forms.Label'
	$labelO365PSConnect = New-Object 'System.Windows.Forms.Label'
	$buttonClose = New-Object 'System.Windows.Forms.Button'
	$InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState'
	#endregion Generated Form Objects

	#----------------------------------------------
	# User Generated Script
	#----------------------------------------------
	$buttonClose_Click={
	
		$formAbout.Close
	}	# --End User Generated Script--
	#----------------------------------------------
	#region Generated Events
	#----------------------------------------------
	
	$Form_StateCorrection_Load=
	{
		#Correct the initial state of the form to prevent the .Net maximized form issue
		$formAbout.WindowState = $InitialFormWindowState
	}
	
	$Form_StoreValues_Closing=
	{
		#Store the control values
	}

	
	$Form_Cleanup_FormClosed=
	{
		#Remove all event handlers from the controls
		try
		{
			$buttonClose.remove_Click($buttonClose_Click)
			$formAbout.remove_Load($Form_StateCorrection_Load)
			$formAbout.remove_Closing($Form_StoreValues_Closing)
			$formAbout.remove_FormClosed($Form_Cleanup_FormClosed)
		}
		catch { Out-Null <# Prevent PSScriptAnalyzer warning #> }
	}
	#endregion Generated Events

	#----------------------------------------------
	#region Generated Form Code
	#----------------------------------------------
	$formAbout.SuspendLayout()
	#
	# formAbout
	#
	$formAbout.Controls.Add($labelVersion12Release1707)
	$formAbout.Controls.Add($labelO365PSConnect)
	$formAbout.Controls.Add($buttonClose)
	$formAbout.AcceptButton = $buttonClose
	$formAbout.AutoScaleDimensions = '6, 13'
	$formAbout.AutoScaleMode = 'Font'
	$formAbout.ClientSize = '284, 107'
	$formAbout.FormBorderStyle = 'FixedDialog'
	$formAbout.MaximizeBox = $False
	$formAbout.MinimizeBox = $False
	$formAbout.Name = 'formAbout'
	$formAbout.StartPosition = 'CenterScreen'
	$formAbout.Text = 'About'
	#
	# labelVersion12Release1707
	#
	$labelVersion12Release1707.AutoSize = $True
	$labelVersion12Release1707.Location = '12, 54'
	$labelVersion12Release1707.Name = 'labelVersion12Release1707'
	$labelVersion12Release1707.Size = '147, 13'
	$labelVersion12Release1707.TabIndex = 2
	$labelVersion12Release1707.Text = 'Version 1.2 - Release 170713'
	#
	# labelO365PSConnect
	#
	$labelO365PSConnect.AutoSize = $True
	$labelO365PSConnect.Location = '12, 23'
	$labelO365PSConnect.Name = 'labelO365PSConnect'
	$labelO365PSConnect.Size = '93, 13'
	$labelO365PSConnect.TabIndex = 1
	$labelO365PSConnect.Text = 'O365 PS Connect'
	#
	# buttonClose
	#
	$buttonClose.Anchor = 'Bottom, Right'
	$buttonClose.DialogResult = 'OK'
	$buttonClose.Location = '197, 72'
	$buttonClose.Name = 'buttonClose'
	$buttonClose.Size = '75, 23'
	$buttonClose.TabIndex = 0
	$buttonClose.Text = '&Close'
	$buttonClose.UseVisualStyleBackColor = $True
	$buttonClose.add_Click($buttonClose_Click)
	$formAbout.ResumeLayout()
	#endregion Generated Form Code

	#----------------------------------------------

	#Save the initial state of the form
	$InitialFormWindowState = $formAbout.WindowState
	#Init the OnLoad event to correct the initial state of the form
	$formAbout.add_Load($Form_StateCorrection_Load)
	#Clean up the control events
	$formAbout.add_FormClosed($Form_Cleanup_FormClosed)
	#Store the control values when form is closing
	$formAbout.add_Closing($Form_StoreValues_Closing)
	#Show the Form
	return $formAbout.ShowDialog()

}
#endregion Source: HelpForm.psf

#Start the application
Main ($CommandLine)
