﻿## Clear Arrays
$SB = @()
$SBS = @()
$today = @()
$Past30 = @()
$past60 = @()
$30onprem = @()
$60onprem = @()
$60 = @()
$30 = @()
$30check = @()

##assign variables for things
#dates needed
$today = get-date
$past30 = (get-date).adddays(-30)
$past60 = (get-date).adddays(-60) 
$logday = get-date -format filedate

#log files
$logpath = 'c:\Tools\logs\Inactiveaccounts\'
$60log = '60day'+$logday+'.csv'
$30log = '30day'+$logday+'.csv'

#Email information
$from = 'Email@Address.com'
$CC = 'Email@Address.com'
$smtpserver = 'Server.email.sender'

#Searchbases
$SBS = @("OU=users,DC=domain,DC=local",
"OU=vendors,DC=domain,DC=local")

###TODO CONNECT TO ONLINE, Get credentials for it
#connecting to on-line modules
$sharepointdomain = 'https://ncphn-admin.sharepoint.com'
#$credential = get-credential
Import-Module Microsoft.Online.SharePoint.PowerShell -DisableNameChecking
Connect-SPOService -Url $sharepointdomain
import-module MSOnline
connect-msolservice
#$session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri 'https://outlook.office365.com/powershell-liveid/' -Credential $credential -Authentication Basic -AllowRedirection
#Import-PSSession $session -AllowClobber
Connect-ExchangeOnline -UserPrincipalName stephen.bell@hnc.org.au -ShowProgress $true

##60 days on prem
#write-host 'looking for the users on prem that have not logged in 60 days'
#foreach ($SB in $SBS){
#	$60onprem += get-aduser -SearchBase $SB -filter 'LastLogonDate -le $past60' -Properties SAMaccountname,DisplayName,company,title,Department,Office,AccountExpirationDate,enabled,LastLogonDate,PasswordLastSet,whenCreated,UserPrincipalName 
#	$60onprem += get-aduser -SearchBase $SB -filter 'LastLogonDate -notlike "*" -AND whencreated -le $past60' -Properties SAMaccountname,DisplayName,company,title,Department,Office,AccountExpirationDate,enabled,LastLogonDate,PasswordLastSet,whenCreated,UserPrincipalName 
#	}

##searching for each person in exchange online. 
#looking for between 60 and 30 days
Write-host 'Checking Exchnage online for 60 days of inactivity'
foreach ($user in $60onprem) {
		$log = search-unifiedauditlog -startdate $past60 -enddate $past30 -UserIds $user.UserPrincipalName -ResultSize 1
		if ($log -eq $null) {write-host $user.SAMaccountname "has no entry for 60 days, flagged to be disabled"
								$60 += get-aduser $user.SAMaccountname -Properties samaccountname,givenname,surname,office,company,title,department,accountexpirationdate,created,enabled,lastlogondate,officephone,manager,mail,displayname
							}
		else {
		write-host $user.SAMaccountname "has an entry for 60 days checking on 30 days"
		$30Check += get-aduser $user.SAMaccountname -Properties samaccountname,givenname,surname,office,company,title,department,accountexpirationdate,created,enabled,lastlogondate,officephone,manager}
	}
#looking for between 30 and today
Write-host 'Checking Exchange online for 30 days of inactivity'
foreach ($user in $Check30) {
		$log = search-unifiedauditlog -startdate $past30 -enddate $today -UserIds $user.UserPrincipalName -ResultSize 1
			if ($log -eq $null) {write-host $user.SAMaccountname "has no entry for 30 days flagged to be disabled"
									$30 += get-aduser $user.SAMaccountname -Properties samaccountname,givenname,surname,office,company,title,department,accountexpirationdate,created,enabled,lastlogondate,officephone,manager,mail,displayname
								}
			else {write-host $user.SAMaccountname "has an entry"}
	}

#30 day check

#check on premise
#write-host 'looking for the users on prem that have not logged in 30 days'
#foreach ($SB in $SBS){
#		$30onprem += get-aduser -SearchBase $SB -filter 'enabled -eq $true -and LastLogonDate -le $past30 -and lastlogondate -ge $past60' -Properties SAMaccountname,DisplayName,company,title,Department,Office,AccountExpirationDate,enabled,LastLogonDate,PasswordLastSet,whenCreated,UserPrincipalName,mail,displayname
#	}

#searching for each person in exchange online. Max is 90 days
Write-host 'Checking Exchange online for 30 days of inactivity'
foreach ($user in $30onprem) {
		$log = search-unifiedauditlog -startdate $past30 -enddate $today -UserIds $user.UserPrincipalName -ResultSize 1
		if ($log -eq $null) {write-host $user.SAMaccountname "has no entry"
								$30 += get-aduser $user.SAMaccountname -Properties samaccountname,givenname,surname,office,company,title,department,accountexpirationdate,created,enabled,lastlogondate,officephone,manager,mail,displayname
								}
		else {write-host $user.SAMaccountname "has an entry"}
	}

#Processing 60 day folk
###grants permissions for a manager to accounts that aren't active for over 60 days 
#looping for each user
#foreach ($UN in $60) { 
#		$ADuser = Get-ADuser $UN -property displayname,mail
#		$ADboss = Get-ADUser $ADuser.manager
#
#		$emailstart = 'The user $UN.displayname has been inactive for 60 days.  The account is scheduled for deletion after 90 days of inactivity. Please contact the Service Desk to have the account re-enabled and have the user log into a computer'
#		# See if user has a OneDrive
#		$ODurl = "https://XXXXXXXXXXX-my.sharepoint.com/personal/" + (($ADuser.userprincipalname.tostring()) -replace '\.','_' -replace '@','_' -replace '-','_')
#		$ODcheck = Get-SPOSite $ODurl
#
#		If ($ODcheck -eq $Null) {$EmailOD = "User does not have a OneDrive"}
#		Else {
#		$EmailOD = "For 30 days, you may access the user's OneDrive here:  "+ $ODurl
#		Set-SPOUser -site $ODurl -LoginName (Get-ADUser $Boss).userprincipalname -IsSiteCollectionAdmin $true
#		}
#
#		# See if user has a mailbox
#		$Mailboxcheck = Get-Mailbox $UN
#		If ($Mailboxcheck -eq $Null) {$EmailMailbox = "User does not have a mailbox"}
#		Else {
#		$EmailMailbox = "User's mailbox should appear in your Outlook within two hours.  It will be deleted in 30 days"
#		Add-MailboxPermission $UN -User $Boss -AccessRights FullAccess -InheritanceType All -AutoMapping $True
#		}
#		Disable-ADaccount $UN
#		$ADuser | Move-ADObject -TargetPath "OU=TerminatedAccounts,OU=Administration,DC=domain,DC=local"
#		Get-ADUser $UN | Rename-ADObject -newname ("del-"+(get-date -format MM/dd/yyyy)+"-"+$UN)
#		$ADboss = @()
#		$to = $ADboss.mail
#		$EmailSubject = "Data access for inactive user:  "+$ADuser.displayname
#		$EmailBody = $emailstart+"<BR><BR>"+$EmailOD+"<BR><BR>"+$EmailMailbox+"<BR><BR>"
#		send-mailmessage -to $to -from $from -cc $CC -Subject $EmailSubject -BodyAsHtml -Body $EmailBody -smtpserver $SMTPServer
#	}


#Disables accounts that aren't active for over 30 days and emailing manager
#	Foreach ($U30 in $30) {
#			$u30mgr = @()
#		$u30mgr2 = @() 
#		$U30 | Disable-ADAccount #disables the account
#		#builds information for the termination
#		
#		$U30MGR = get-aduser $U30.Manager -properties manager,mail
#		$U30MGR2 = Get-aduser $u30mgr.manager -properties manager,mail
#		$disableSubject = 'Inactive Account - '+$U30.displayname
#		$disableBody = 'Greetings,<BR><BR> 
#		The account for User ' +$U30.displayname +' has been inactive for over 30 days.  <BR>	email blah blah <BR>'
#		 
#		$disableTO = $U30MGR.mail,$u30mgr2.mail
#
#		send-mailmessage -to $disableto -from $from -cc $CC -Subject $disableSubject -BodyAsHtml -Body $disableBody -smtpserver $SMTPSErver
#	}

$60 | export-csv $logpath$60log -force -notypeinformation
$30 | export-csv $logpath$30log -force -notypeinformation